package com.example.sarahemmanuels.businessappcard;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.ViewSwitcher;
import android.widget.ViewSwitcher.ViewFactory;

import static android.support.v7.widget.AppCompatDrawableManager.get;

public class MainActivity extends AppCompatActivity {

    ImageSwitcher sw;
    Button previousBtn, nextBtn, fbBtn, twitterBtn, instagramBtn;
    int imageIds[] = {R.drawable.image1, R.drawable.image2, R.drawable.image3, R.drawable.image4, R.drawable.image5, R.drawable.image6, R.drawable.image7, R.drawable.image8, R.drawable.image9};
    int currentIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nextBtn = (Button) findViewById(R.id.right_button);
        previousBtn = (Button) findViewById(R.id.left_button);
        fbBtn = (Button) findViewById(R.id.fb_btn);
        twitterBtn = (Button) findViewById(R.id.twitter_btn);
        instagramBtn = (Button)findViewById(R.id.instagram_btn);

        sw = (ImageSwitcher) findViewById(R.id.imgSw);
        sw.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView slideView= new ImageView(MainActivity.this);
                slideView.setImageResource(imageIds[currentIndex]);
                return slideView;
            }
        });

        sw.setInAnimation(this, android.R.anim.slide_in_left);
        sw.setOutAnimation(this, android.R.anim.slide_out_right);

        previousBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Toast.makeText(getApplicationContext(), "previous Image", Toast.LENGTH_LONG).show();
                if (currentIndex > 0)
                    currentIndex--;
                if (currentIndex < 0)
                    currentIndex = 0;
                sw.setImageResource(imageIds[currentIndex]);
            }
        });

        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(getApplicationContext(), "Next Image", Toast.LENGTH_LONG).show();
                if (currentIndex < imageIds.length)
                    currentIndex++;
                if (currentIndex >= imageIds.length)
                    currentIndex = imageIds.length - 1;
                sw.setImageResource(imageIds[currentIndex]);
            }
        });

        fbBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fbUrl = "https://www.facebook.com";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(fbUrl));
                startActivity(intent);
            }
        });

        twitterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String twitterUrl = "https://www.twitter.com";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(twitterUrl));
                startActivity(intent);
            }
        });

        instagramBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String instagramUrl = "https://www.instagram.com";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(instagramUrl));
                startActivity(intent);
            }
        });
    }
}
